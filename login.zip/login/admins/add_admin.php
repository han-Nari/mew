<?php 
	require_once "../includes/finance_db_connect.php";
	require_once "../includes/session.php";
	require_once "save_admin_into_db.php";
		
	$admin_id = $_SESSION['email'];

	if(!isset($admin_id)){
	   header('location:../login.php');
	}

	if (!isset($_SESSION["passCode"])) {
	    header('location:admins.php');
	    exit;
	}

	// Unset only the 'passCode' session variable
	unset($_SESSION["passCode"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Add Admin</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "admins.css"; ?>
		<?php include "add_admin.css"; ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section class="center">
			<div class="add_admin">
				<span class="title">Add Admin</span>
				<form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">	
					<div class="box username">
						<i class="fa-solid fa-user"></i>
						<input type="text" name="username" placeholder="Username">
					</div>

					<span class="errors">
						<?php echo $errors["username"]; ?>
					</span>

					<div class="box pwd">
						<i class="fa-solid fa-key"></i>
						<input type="password" id="password"  name="password" placeholder="Password">
						<div class="message">Password is <span id="strength"></span></div>
					</div>

					<span class="errors">
						<?php echo $errors["password"]; ?>
					</span>

					<div class="box pwd">
						<i class="fa-solid fa-key"></i>
						<input type="password" id="cpassword" name="passwordCon" placeholder="Password repeat">
						<div class="cmessage">Password is <span id="cstrength"></span></div>
					</div>

						<span class="errors">
						<?php echo $errors["password"]; ?>
					</span>

					<div class="box email">
						<i class="fa-solid fa-envelope"></i>
						<input type="email" name="email" placeholder="Email">
					</div>

					<span class="errors">
						<?php echo $errors["email"]; ?>
					</span>

					<div class="box">
						<input type="file" id="file" name="image" required class="box" accept="image/jpg, image/png, image/jpeg">
					</div>

					<span class="errors">
						<?php echo $errors["img"]; ?>
					</span>

					<div class="box">
						<input class="btn" type="submit" name="submit" value="Create Admin">
					</div>

					<div class="back">
						<p class="white">Back to <a id="back" href="admins.php">Admin</a></p>
					</div>
				</form>
			</div>	
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
		let pass = document.querySelector('#password')
		let cpass = document.querySelector('#cpassword');
		let message = document.querySelector('.message');
		let cmessage = document.querySelector('.cmessage');
		let str = document.querySelector('#strength');
		let cstr = document.querySelector('#cstrength');

		pass.addEventListener('input', ()=> {
			if(pass.value.length > 0) {
				message.style.display = 'block';
			} else {
				message.style.display = 'none';
			}

			if(pass.value.length < 6) {
				str.innerHTML = 'weak';
				message.style.color = '#f00000';
			} else if(pass.value.length >= 6) {
				str.innerHTML = 'strong';
				message.style.color = '#00ff00';
			}
		});

		cpass.addEventListener('input', ()=> {
			if(cpass.value.length > 0) {
				cmessage.style.display = 'block';
			} else {
				cmessage.style.display = 'none';
			}

			if(cpass.value.length < 6) {
				cstr.innerHTML = 'weak';
				cmessage.style.color = '#f00000';
			} else if(cpass.value.length >= 6) {
				cstr.innerHTML = 'strong';
				cmessage.style.color = '#00ff00';
			}
		});
	</script>
</body>
</html>



	