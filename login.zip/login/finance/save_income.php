<?php 


if($_SERVER["REQUEST_METHOD"] == "POST") {
	$date = $_POST["date"];
	$income = $_POST["income"];
	$amount = $_POST["amount"];
	$total = $_POST["total"];

	// Query
	$query = "INSERT INTO incomes (dates, income, amount, total) VALUES (:dates, :income, :amount, :total)";
	$stmt =$pdo->prepare($query);
	$stmt->bindParam(":dates", $date);
	$stmt->bindParam(":income", $income);
	$stmt->bindParam(":amount", $amount);
	$stmt->bindParam(":total", $total);
	$stmt->execute();

	if($stmt) {
		header("location: income.php");
	}
}