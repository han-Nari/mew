<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";
	require_once "save_income.php";

	$admin_id = $_SESSION['email'];

	if (!isset($admin_id)) {
	    header('location:../login.php');
	}

	unset($_SESSION["passCode"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Philippine Real Property Tax Calculator</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "income.css"; ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section class="grid">
			<form class="top" id="incomeForm" action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">	
			 	<h1>Income Management System</h1>

		    	<label for="incomeType">Income Type:</label>
		    	<input type="text" id="incomeType" name="incomeType" placeholder="Income Type" required>

		        <label for="amount">Amount:</label>
		        <input type="number" id="amount" name="amount" placeholder="Amount" required>

		       <input type="submit" class="btn" name="submit" value="Add Income">
		     </form>
		     <form id="incomeForm" action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
			<div class="revenue center">
			  <h2>Total Revenue Collection</h2>
			  <p id="totalRevenue" name="total" >PHP 0.00</p>
			</div>

			<div class="incomeTable bottom">
		     <table>
				<caption>
			 		<h2>Income Records</h2>
				</caption>
		          <tr>
		            <th>Date</th>
		            <th>Income Type</th>
		            <th>Amount</th>
		          </tr>
		        </thead>
		        <tbody id="incomeRecords">
		          <!-- Income records will be dynamically added here -->
		        </tbody>
		      </table>
		    </div>
		   		<input type="submit" class="btn" name="submit" value="Save">
		    </form>	
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
	</script>
	<script type="text/javascript">
		document.addEventListener('DOMContentLoaded', function () {
		  const incomeForm = document.getElementById('incomeForm');
		  const incomeRecords = document.getElementById('incomeRecords');
		  const totalRevenueDisplay = document.getElementById('totalRevenue');
		  let totalRevenue = 0;

		  incomeForm.addEventListener('submit', function (e) {
		    e.preventDefault();
		    const incomeType = document.getElementById('incomeType').value;
		    const amount = parseFloat(document.getElementById('amount').value);
		    const date = new Date().toLocaleDateString();

		    const newRow = document.createElement('tr');
		    newRow.innerHTML = `
		      <td name="date">${date}</td>
		      <td name="income">${incomeType}</td>
		      <td name="amount">${amount.toFixed(2)}</td>
		    `;
		    incomeRecords.appendChild(newRow);

		    // Update total revenue
		    totalRevenue += amount;
		    totalRevenueDisplay.textContent = `PHP ${totalRevenue.toFixed(2)}`;

		    // Clear input fields after adding income
		    document.getElementById('incomeType').value = '';
		    document.getElementById('amount').value = '';
		  });
		});
	</script>
</body>
</html>



	