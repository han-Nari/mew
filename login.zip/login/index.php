<?php
session_start(); // Start the session to use session variables

// Initialize income records if not already set
if (!isset($_SESSION['incomeRecords'])) {
    $_SESSION['incomeRecords'] = [];
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $incomeType = $_POST['incomeType'];
    $amount  = floatval($_POST['amount']);
    $date = date("Y-m-d");

    // Append the new income record to the session variable
    $_SESSION['incomeRecords'][] = [
        "date" => $date,
        "incomeType" => $incomeType,
        "amount" => $amount,
    ];

    // Redirect to the same page to avoid form resubmission issues
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// Calculate total revenue
$totalRevenue = 0;
foreach ($_SESSION['incomeRecords'] as $record) {
    $totalRevenue += $record['amount'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Income Management System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Barangay Income Management System</h1>
        <form id="incomeForm" method="POST">
            <label for="incomeType">Income Type:</label>
            <input type="text" id="incomeType" name="incomeType" required>

            <label for="amount">Amount:</label>
            <input type="number" id="amount" name="amount" required>

            <button type="submit">Add Income</button>
        </form>
        <div class="revenue">
            <h2>Total Revenue Collection</h2>
            <p id="totalRevenue">PHP <?php echo number_format($totalRevenue, 2); ?></p>
        </div>

        <div class="incomeTable">
            <h2>Income Records</h2>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Income Type</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody id="incomeRecords">
                    <?php foreach ($_SESSION['incomeRecords'] as $record): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($record['date']); ?></td>
                        <td><?php echo htmlspecialchars($record['incomeType']); ?></td>
                        <td><?php echo htmlspecialchars(number_format($record['amount'], 2)); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
